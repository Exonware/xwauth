#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/riot_games.py
Riot Games OAuth Provider
Riot Games OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class RiotGamesProvider(ABaseProvider):
    """Riot Games OAuth 2.0 provider."""
    AUTHORIZATION_URL = "https://auth.riotgames.com/oauth2/authorize"
    TOKEN_URL = "https://auth.riotgames.com/oauth2/token"
    USERINFO_URL = "https://auth.riotgames.com/userinfo"

    def __init__(self, client_id: str, client_secret: str, **kwargs):
        """
        Initialize Riot Games provider.
        Args:
            client_id: Riot Games Client ID
            client_secret: Riot Games Client Secret
            **kwargs: Additional configuration
        """
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=self.AUTHORIZATION_URL,
            token_url=self.TOKEN_URL,
            userinfo_url=self.USERINFO_URL,
            **kwargs
        )
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "riot_games"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.RIOT_GAMES

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Riot Games.
        Args:
            access_token: Access token
        Returns:
            User information dictionary
        """
        user_info = await super().get_user_info(access_token)
        # Normalize Riot Games user info format
        return {
            'id': user_info.get('sub'),
            'username': user_info.get('preferred_username'),
            'email': user_info.get('email'),
            'name': user_info.get('name'),
        }
