#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/crunchyroll.py
Crunchyroll OAuth Provider
Crunchyroll OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class CrunchyrollProvider(ABaseProvider):
    """Crunchyroll OAuth 2.0 provider."""
    AUTHORIZATION_URL = "https://www.crunchyroll.com/auth/v1/authorize"
    TOKEN_URL = "https://www.crunchyroll.com/auth/v1/token"
    USERINFO_URL = "https://www.crunchyroll.com/accounts/v1/me"

    def __init__(self, client_id: str, client_secret: str, **kwargs):
        """
        Initialize Crunchyroll provider.
        Args:
            client_id: Crunchyroll Client ID
            client_secret: Crunchyroll Client Secret
            **kwargs: Additional configuration
        """
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=self.AUTHORIZATION_URL,
            token_url=self.TOKEN_URL,
            userinfo_url=self.USERINFO_URL,
            **kwargs
        )
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "crunchyroll"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.CRUNCHYROLL

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Crunchyroll.
        Args:
            access_token: Access token
        Returns:
            User information dictionary
        """
        user_info = await super().get_user_info(access_token)
        # Normalize Crunchyroll user info format
        return {
            'id': str(user_info.get('account_id')),
            'username': user_info.get('username'),
            'email': user_info.get('email'),
            'premium': user_info.get('premium', False),
        }
