#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/viber.py
Viber OAuth Provider
Viber OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class ViberProvider(ABaseProvider):
    """Viber OAuth 2.0 provider."""
    AUTHORIZATION_URL = "https://auth.viber.com/oauth/authorize"
    TOKEN_URL = "https://auth.viber.com/oauth/token"
    USERINFO_URL = "https://chatapi.viber.com/pa/get_user_details"

    def __init__(self, client_id: str, client_secret: str, **kwargs):
        """
        Initialize Viber provider.
        Args:
            client_id: Viber Client ID
            client_secret: Viber Client Secret
            **kwargs: Additional configuration
        """
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=self.AUTHORIZATION_URL,
            token_url=self.TOKEN_URL,
            userinfo_url=self.USERINFO_URL,
            **kwargs
        )
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "viber"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.VIBER

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Viber.
        Args:
            access_token: Access token
        Returns:
            User information dictionary
        """
        user_info = await super().get_user_info(access_token)
        # Normalize Viber user info format
        return {
            'id': str(user_info.get('id')),
            'name': user_info.get('name'),
            'avatar': user_info.get('avatar'),
        }
