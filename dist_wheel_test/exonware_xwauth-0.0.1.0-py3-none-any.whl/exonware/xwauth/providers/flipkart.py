#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/flipkart.py
Flipkart OAuth Provider
Flipkart OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class FlipkartProvider(ABaseProvider):
    """Flipkart OAuth 2.0 provider."""
    AUTHORIZATION_URL = "https://api.flipkart.net/oauth-service/oauth/authorize"
    TOKEN_URL = "https://api.flipkart.net/oauth-service/oauth/token"
    USERINFO_URL = "https://api.flipkart.net/oauth-service/oauth/user"

    def __init__(self, client_id: str, client_secret: str, **kwargs):
        """
        Initialize Flipkart provider.
        Args:
            client_id: Flipkart API Key
            client_secret: Flipkart API Secret
            **kwargs: Additional configuration
        """
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=self.AUTHORIZATION_URL,
            token_url=self.TOKEN_URL,
            userinfo_url=self.USERINFO_URL,
            **kwargs
        )
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "flipkart"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.FLIPKART

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Flipkart.
        Args:
            access_token: Access token
        Returns:
            User information dictionary
        """
        user_info = await super().get_user_info(access_token)
        # Normalize Flipkart user info format
        return {
            'id': str(user_info.get('id')),
            'email': user_info.get('email'),
            'name': user_info.get('name'),
            'phone': user_info.get('phone'),
        }
