#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/element.py
Element OAuth Provider
Element (Matrix-based) OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any, Optional
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class ElementProvider(ABaseProvider):
    """Element (Matrix-based) OAuth 2.0 provider."""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        homeserver_url: str = "https://matrix.org",
        **kwargs
    ):
        """
        Initialize Element provider.
        Args:
            client_id: Matrix Client ID
            client_secret: Matrix Client Secret
            homeserver_url: Matrix homeserver URL (default: https://matrix.org)
            **kwargs: Additional configuration
        """
        # Element uses Matrix OAuth endpoints
        authorization_url = f"{homeserver_url}/_matrix/client/r0/login/sso/redirect/oauth2/authorize"
        token_url = f"{homeserver_url}/_matrix/client/r0/login/sso/redirect/oauth2/token"
        userinfo_url = f"{homeserver_url}/_matrix/client/r0/account/whoami"
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=authorization_url,
            token_url=token_url,
            userinfo_url=userinfo_url,
            **kwargs
        )
        self.homeserver_url = homeserver_url
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "element"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.ELEMENT

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Element (Matrix).
        Args:
            access_token: Access token (Matrix access token)
        Returns:
            User information dictionary
        """
        if self._async_http_client is None:
            from exonware.xwsystem.http_client import AsyncHttpClient
            self._async_http_client = AsyncHttpClient()
        response = await self._async_http_client.get(
            self.USERINFO_URL,
            headers={'Authorization': f'Bearer {access_token}'}
        )
        if response.status_code != 200:
            from ..errors import XWProviderConnectionError
            raise XWProviderConnectionError(
                f"User info request failed: {response.status_code}",
                error_code="userinfo_failed",
                context={'status_code': response.status_code}
            )
        user_info = response.json()
        # Normalize Element user info format
        return {
            'id': user_info.get('user_id'),
        }
