#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/bilibili.py
Bilibili OAuth Provider
Bilibili (哔哩哔哩) OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class BilibiliProvider(ABaseProvider):
    """Bilibili (哔哩哔哩) OAuth 2.0 provider."""
    AUTHORIZATION_URL = "https://passport.bilibili.com/oauth/authorize"
    TOKEN_URL = "https://passport.bilibili.com/api/oauth2/access_token"
    USERINFO_URL = "https://api.bilibili.com/x/space/myinfo"

    def __init__(self, client_id: str, client_secret: str, **kwargs):
        """
        Initialize Bilibili provider.
        Args:
            client_id: Bilibili App Key
            client_secret: Bilibili App Secret
            **kwargs: Additional configuration
        """
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=self.AUTHORIZATION_URL,
            token_url=self.TOKEN_URL,
            userinfo_url=self.USERINFO_URL,
            **kwargs
        )
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "bilibili"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.BILIBILI

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Bilibili.
        Args:
            access_token: Access token
        Returns:
            User information dictionary
        """
        user_info = await super().get_user_info(access_token)
        # Normalize Bilibili user info format
        data = user_info.get('data', user_info)
        return {
            'id': str(data.get('mid')),
            'name': data.get('name'),
            'avatar_url': data.get('face'),
            'sign': data.get('sign'),
        }
