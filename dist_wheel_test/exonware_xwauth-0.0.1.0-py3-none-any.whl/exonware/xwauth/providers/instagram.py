#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/providers/instagram.py
Instagram OAuth Provider
Instagram OAuth 2.0 provider implementation.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 25-Jan-2026
"""

from typing import Any
from exonware.xwsystem import get_logger
from ..defs import ProviderType
from .base import ABaseProvider
logger = get_logger(__name__)


class InstagramProvider(ABaseProvider):
    """Instagram OAuth 2.0 provider."""
    AUTHORIZATION_URL = "https://api.instagram.com/oauth/authorize"
    TOKEN_URL = "https://api.instagram.com/oauth/access_token"
    USERINFO_URL = "https://graph.instagram.com/me"

    def __init__(self, client_id: str, client_secret: str, **kwargs):
        """
        Initialize Instagram provider.
        Args:
            client_id: Instagram OAuth client ID
            client_secret: Instagram OAuth client secret
            **kwargs: Additional configuration
        """
        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            authorization_url=self.AUTHORIZATION_URL,
            token_url=self.TOKEN_URL,
            userinfo_url=self.USERINFO_URL,
            **kwargs
        )
    @property

    def provider_name(self) -> str:
        """Get provider name."""
        return "instagram"
    @property

    def provider_type(self) -> ProviderType:
        """Get provider type."""
        return ProviderType.INSTAGRAM

    async def get_user_info(self, access_token: str) -> dict[str, Any]:
        """
        Get user information from Instagram.
        Args:
            access_token: Access token
        Returns:
            User information dictionary
        """
        # Instagram requires fields parameter
        if self._async_http_client is None:
            from exonware.xwsystem.http_client import AsyncHttpClient
            self._async_http_client = AsyncHttpClient()
        fields = "id,username"
        url = f"{self.USERINFO_URL}?fields={fields}"
        response = await self._async_http_client.get(
            url,
            headers={'Authorization': f'Bearer {access_token}'}
        )
        if response.status_code != 200:
            from ..errors import XWProviderConnectionError
            raise XWProviderConnectionError(
                f"User info request failed: {response.status_code}",
                error_code="userinfo_failed",
                context={'status_code': response.status_code}
            )
        user_info = response.json()
        # Normalize Instagram user info format
        return {
            'id': str(user_info.get('id')),
            'username': user_info.get('username'),
        }
