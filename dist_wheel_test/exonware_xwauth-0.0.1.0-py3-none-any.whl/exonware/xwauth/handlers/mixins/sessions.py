# exonware/xwauth/api/services/mixins/sessions.py
"""Sessions: list, revoke, revoke_others."""

from __future__ import annotations
from typing import Any
from fastapi import Request, Depends, Header
from fastapi.responses import JSONResponse, RedirectResponse, Response
from exonware.xwaction import XWAction
from exonware.xwaction.defs import ActionProfile
from exonware.xwsystem.security.oauth_errors import oauth_error_response
from exonware.xwauth.oauth_http.errors import oauth_error_to_http
from exonware.xwauth.ops_hooks import track_critical_handler
from .._common import (
    AUTH_TAGS,
    get_auth,
    get_bearer_token,
    get_current_user_id,
)


def _oauth_json_error(
    error: str,
    description: str,
    *,
    status_code: int | None = None,
) -> JSONResponse:
    body, status = oauth_error_response(
        error,
        description,
        status_code=status_code,
    )
    return JSONResponse(content=body, status_code=status)
@XWAction(
    operationId="auth_sessions_list",
    summary="List Active Sessions",
    method="GET",
    description="List all active sessions for the current authenticated user.",
    tags=AUTH_TAGS,
    engine="fastapi",
    profile=ActionProfile.ENDPOINT,
    security="Bearer",
    responses={200: {"description": "List of active sessions"}, 401: {"description": "Authentication required"}},
    audit=True,
    in_types={},
)
async def sessions_list(request: Request) -> Any:
    """List all active sessions for current user."""
    user_id = await get_current_user_id(request)
    if not user_id:
        return _oauth_json_error("unauthorized", "Authentication required", status_code=401)
    auth = get_auth(request)
    try:
        async with track_critical_handler(request, "sessions_list"):
            sessions = await auth._session_manager.list_user_sessions(user_id)
            return {"sessions": sessions}
    except Exception as e:
        body, status = oauth_error_to_http(e)
        return JSONResponse(content=body, status_code=status)
# -----------------------------------------------------------------------------
# DELETE /auth/sessions/{session_id}
# -----------------------------------------------------------------------------
@XWAction(
    operationId="auth_sessions_revoke",
    summary="Revoke Specific Session",
    method="DELETE",
    description="""
    Revoke a specific session by session_id.
    This will log out the user from that specific device/session.
    Security: Requires Bearer token authentication.
    Only the session owner can revoke their own sessions.
    """,
    tags=AUTH_TAGS,
    engine="fastapi",
    profile=ActionProfile.ENDPOINT,
    security="Bearer",
    responses={
        204: {"description": "Session revoked successfully"},
        401: {"description": "Authentication required"},
        403: {"description": "Not authorized to revoke this session"},
        404: {"description": "Session not found"},
    },
    rate_limit="100/hour",
    audit=True,
    in_types={
        "session_id": {
            "type": "string",
            "description": "Session identifier to revoke",
            "minLength": 1,
            "maxLength": 256
        }
    },
)
async def sessions_revoke(session_id: str, request: Request) -> Any:
    """Revoke a specific session."""
    user_id = await get_current_user_id(request)
    if not user_id:
        return _oauth_json_error("unauthorized", "Authentication required", status_code=401)
    auth = get_auth(request)
    try:
        async with track_critical_handler(request, "sessions_revoke"):
            # Verify session belongs to user
            session = await auth._session_manager._storage.get_session(session_id)
            if not session:
                return _oauth_json_error("session_not_found", "Session not found", status_code=404)
            if session.user_id != user_id:
                return _oauth_json_error(
                    "forbidden",
                    "Not authorized to revoke this session",
                    status_code=403,
                )
            await auth._session_manager.revoke_session(session_id)
            return Response(status_code=204)
    except Exception as e:
        body, status = oauth_error_to_http(e)
        return JSONResponse(content=body, status_code=status)
# -----------------------------------------------------------------------------
# DELETE /auth/sessions/exclude-current
# -----------------------------------------------------------------------------
@XWAction(
    operationId="auth_sessions_revoke_others",
    summary="Logout All Other Devices",
    method="DELETE",
    description="""
    Revoke all active sessions except the current one.
    This will log out the user from all other devices while keeping
    the current session active.
    Security: Requires Bearer token authentication.
    """,
    tags=AUTH_TAGS,
    engine="fastapi",
    profile=ActionProfile.ENDPOINT,
    security="Bearer",
    responses={
        200: {"description": "Other sessions revoked successfully"},
        401: {"description": "Authentication required"},
    },
    examples={
        "response": {
            "revoked_count": 3,
            "message": "Revoked 3 other sessions"
        }
    },
    rate_limit="10/hour",
    audit=True,
    in_types={},  # Exclude Request parameter from schema
)
async def sessions_revoke_others(request: Request) -> Any:
    """Revoke all sessions except the current one."""
    user_id = await get_current_user_id(request)
    if not user_id:
        return _oauth_json_error("unauthorized", "Authentication required", status_code=401)
    # Get current session ID from token
    token = get_bearer_token(request)
    if not token:
        return _oauth_json_error("unauthorized", "Bearer token required", status_code=401)
    auth = get_auth(request)
    try:
        async with track_critical_handler(request, "sessions_revoke_others"):
            # Extract session_id from token claims (if stored in token)
            current_session_id = None
            # Try to extract session_id from token
            token_manager = getattr(auth, '_token_manager', None)
            if token_manager:
                try:
                    # Try JWT token first
                    if hasattr(token_manager, '_jwt_manager') and token_manager._jwt_manager:
                        try:
                            payload = token_manager._jwt_manager.validate_token(token)
                            current_session_id = payload.get('session_id')
                        except Exception:
                            pass
                    # Try opaque token if JWT didn't work
                    if not current_session_id and hasattr(token_manager, '_opaque_manager'):
                        try:
                            token_data = await token_manager._opaque_manager.get_token(token)
                            if token_data:
                                current_session_id = token_data.get('attributes', {}).get('session_id')
                        except Exception:
                            pass
                except Exception:
                    pass
            # Fallback: Find current session (most recently accessed active session)
            if not current_session_id:
                all_sessions = await auth._session_manager._storage.list_user_sessions(user_id)
                active_sessions = [s for s in all_sessions if s.is_active()]
                if active_sessions:
                    # Sort by last_accessed_at, most recent first
                    active_sessions.sort(key=lambda s: s.last_accessed_at, reverse=True)
                    current_session_id = active_sessions[0].id
            if not current_session_id:
                return _oauth_json_error("no_active_session", "No active session found")
            # Revoke all except current
            revoked_count = await auth._session_manager.revoke_all_sessions_except(
                user_id=user_id,
                exclude_session_id=current_session_id
            )
            return {
                "revoked_count": revoked_count,
                "message": f"Revoked {revoked_count} other session(s)"
            }
    except Exception as e:
        body, status = oauth_error_to_http(e)
        return JSONResponse(content=body, status_code=status)
