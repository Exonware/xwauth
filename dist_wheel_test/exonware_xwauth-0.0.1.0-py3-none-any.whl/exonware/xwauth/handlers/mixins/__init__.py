# exonware/xwauth/api/services/mixins/__init__.py
"""Service-grouped mixins for xwauth API."""

from . import auth_core
from . import client_registration
from . import user
from . import password
from . import otp
from . import magic_link
from . import mfa
from . import passkeys
from . import sessions
from . import organizations
from . import sso_providers
from . import saml
from . import fga
from . import webhooks
from . import admin
from . import system
from . import oauth1
from . import scim
__all__ = [
    "auth_core",
    "client_registration",
    "user",
    "password",
    "otp",
    "magic_link",
    "mfa",
    "passkeys",
    "sessions",
    "organizations",
    "sso_providers",
    "saml",
    "fga",
    "webhooks",
    "admin",
    "system",
    "oauth1",
    "scim",
]
