#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/defs.py
Type Definitions and Enums
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
Generation Date: 20-Dec-2025
"""

from enum import Enum
from typing import Optional, Any
# ==============================================================================
# GRANT TYPES
# ==============================================================================


class GrantType(str, Enum):
    """OAuth 2.0 grant types."""
    AUTHORIZATION_CODE = "authorization_code"
    CLIENT_CREDENTIALS = "client_credentials"
    RESOURCE_OWNER_PASSWORD = "password"
    REFRESH_TOKEN = "refresh_token"
    DEVICE_CODE = "urn:ietf:params:oauth:grant-type:device_code"
    TOKEN_EXCHANGE = "urn:ietf:params:oauth:grant-type:token-exchange"  # RFC 8693
# ==============================================================================
# TOKEN TYPES
# ==============================================================================


class TokenType(str, Enum):
    """Token types."""
    JWT = "JWT"
    OPAQUE = "opaque"
    BEARER = "Bearer"
    MAC = "MAC"  # OAuth 2.0 MAC tokens (rarely used)
# ==============================================================================
# RESPONSE TYPES
# ==============================================================================


class ResponseType(str, Enum):
    """OAuth 2.0 response types."""
    CODE = "code"
    TOKEN = "token"  # Implicit flow
    ID_TOKEN = "id_token"  # OpenID Connect
    ID_TOKEN_TOKEN = "id_token token"  # OpenID Connect
    CODE_ID_TOKEN = "code id_token"  # OpenID Connect
    CODE_TOKEN = "code token"  # OpenID Connect
    CODE_ID_TOKEN_TOKEN = "code id_token token"  # OpenID Connect
# ==============================================================================
# CLIENT TYPES
# ==============================================================================


class ClientType(str, Enum):
    """OAuth 2.0 client types."""
    PUBLIC = "public"
    CONFIDENTIAL = "confidential"
# ==============================================================================
# SESSION STATUS
# ==============================================================================


class SessionStatus(str, Enum):
    """Session status."""
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    TERMINATED = "terminated"
# ==============================================================================
# USER STATUS
# ==============================================================================


class UserStatus(str, Enum):
    """User account status."""
    ACTIVE = "active"
    PENDING = "pending"
    SUSPENDED = "suspended"
    DISABLED = "disabled"
    DELETED = "deleted"
# ==============================================================================
# MFA METHODS
# ==============================================================================


class MFAMethod(str, Enum):
    """Multi-factor authentication methods."""
    TOTP = "totp"
    SMS = "sms"
    EMAIL = "email"
    WEBAUTHN = "webauthn"
    BACKUP_CODE = "backup_code"
# ==============================================================================
# PROVIDER TYPES
# ==============================================================================


class ProviderType(str, Enum):
    """OAuth provider types."""
    # Social / Consumer IdPs
    GOOGLE = "google"
    GITHUB = "github"
    DISCORD = "discord"
    SLACK = "slack"
    MICROSOFT = "microsoft"
    APPLE = "apple"
    SAMSUNG = "samsung"
    FACEBOOK = "facebook"
    TWITTER = "twitter"
    LINKEDIN = "linkedin"
    REDDIT = "reddit"
    SPOTIFY = "spotify"
    DROPBOX = "dropbox"
    PINTEREST = "pinterest"
    TUMBLR = "tumblr"
    VIMEO = "vimeo"
    # Additional social providers
    AMAZON = "amazon"
    INSTAGRAM = "instagram"
    YAHOO = "yahoo"
    PAYPAL = "paypal"
    TIKTOK = "tiktok"
    SNAPCHAT = "snapchat"
    TELEGRAM = "telegram"
    THREADS = "threads"
    MASTODON = "mastodon"
    BLUESKY = "bluesky"
    MEDIUM = "medium"
    # Messaging apps
    WHATSAPP = "whatsapp"
    SIGNAL = "signal"
    VIBER = "viber"
    LINE = "line"
    MICROSOFT_TEAMS = "microsoft_teams"
    ZOOM = "zoom"
    SKYPE = "skype"
    KAKAOTALK = "kakaotalk"
    ZALO = "zalo"
    THREEMA = "threema"
    WIRE = "wire"
    ELEMENT = "element"
    MATRIX = "matrix"
    ROCKET_CHAT = "rocket_chat"
    MATTERMOST = "mattermost"
    # Live streaming platforms
    LIVEME = "liveme"
    JACO = "jaco"
    TANGO = "tango"
    BIGO_LIVE = "bigo_live"
    YOUNOW = "younow"
    PERISCOPE = "periscope"
    # Global AI/LLM platforms
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE_GEMINI = "google_gemini"
    AZURE_OPENAI = "azure_openai"
    COHERE = "cohere"
    HUGGING_FACE = "hugging_face"
    MISTRAL = "mistral"
    PERPLEXITY = "perplexity"
    TOGETHER_AI = "together_ai"
    GROQ = "groq"
    # Chinese AI/LLM platforms
    ALIBABA_TONGYI = "alibaba_tongyi"
    TENCENT_HUNYUAN = "tencent_hunyuan"
    IFlyTEK = "iflytek"
    ZHIPU_AI = "zhipu_ai"
    MINIMAX = "minimax"
    MOONSHOT_AI = "moonshot_ai"
    DEEPSEEK = "deepseek"
    QWEN = "qwen"
    CHATGLM = "chatglm"
    # Russian AI/LLM platforms
    GIGACHAT = "gigachat"
    SBER_AI = "sber_ai"
    # Middle Eastern AI/LLM platforms
    # (Fewer options - will add as available)
    # Russian social media
    ODNOKLASSNIKI = "odnoklassniki"
    MAIL_RU = "mail_ru"
    MY_WORLD = "my_world"
    # Additional Chinese social media
    ZHIHU = "zhihu"
    BILIBILI = "bilibili"
    KUAISHOU = "kuaishou"
    # Middle Eastern job/shop platforms
    BAYT = "bayt"
    AKHTABOOT = "akhtaboot"
    WUZZUF = "wuzzuf"
    GULF_TALENTS = "gulf_talents"
    NAFS = "nafs"
    # Developer / Work platforms
    GITLAB = "gitlab"
    BITBUCKET = "bitbucket"
    STACK_OVERFLOW = "stack_overflow"
    SALESFORCE = "salesforce"
    BOX = "box"
    BOX_ENTERPRISE = "box_enterprise"
    SHOPIFY = "shopify"
    WORDPRESS = "wordpress"
    DROPBOX_BUSINESS = "dropbox_business"
    BIGCOMMERCE = "bigcommerce"
    WOOCOMMERCE = "woocommerce"
    SQUARE = "square"
    STRIPE_CONNECT = "stripe"
    PLAID = "plaid"
    YODLEE = "yodlee"
    MX = "mx"
    TRULIOO = "trulioo"
    ONFIDO = "onfido"
    JUMIO = "jumio"
    AMAZON_COGNITO_USER_POOL = "amazon_cognito_user_pool"
    AUTH_JS_META = "auth_js_meta"
    YAMMER = "yammer"
    SOUNDCLOUD = "soundcloud"
    EVERNOTE = "evernote"
    REPLIT = "replit"
    CODEPEN = "codepen"
    CODESANDBOX = "codesandbox"
    GLITCH = "glitch"
    VERCEL = "vercel"
    NETLIFY = "netlify"
    CIRCLECI = "circleci"
    DOCKER_HUB = "docker_hub"
    NPM = "npm"
    # Regional providers
    VKONTAKTE = "vkontakte"
    YANDEX = "yandex"
    WEIBO = "weibo"
    RENREN = "renren"
    AOL = "aol"
    # Chinese providers
    ALIPAY = "alipay"
    WECHAT = "wechat"
    QQ = "qq"
    BAIDU = "baidu"
    DOUYIN = "douyin"
    XIAOHONGSHU = "xiaohongshu"
    DINGTALK = "dingtalk"
    TAOBAO = "taobao"
    TMALL = "tmall"
    # Middle Eastern providers
    NOON = "noon"
    CAREEM = "careem"
    ANGHAMI = "anghami"
    TAMARA = "tamara"
    STC_PAY = "stc_pay"
    FAWRY = "fawry"
    PAYTABS = "paytabs"
    RAKBANK = "rakbank"
    # Streaming platforms
    TWITCH = "twitch"
    PANDORA = "pandora"
    TIDAL = "tidal"
    DEEZER = "deezer"
    CRUNCHYROLL = "crunchyroll"
    YOUTUBE_MUSIC = "youtube_music"
    YOUTUBE = "youtube"
    IHEARTRADIO = "iheartradio"
    SIRIUSXM = "siriusxm"
    APPLE_MUSIC = "apple_music"
    # Shopping / E-commerce platforms
    EBAY = "ebay"
    ETSY = "etsy"
    MERCADO_LIBRE = "mercado_libre"
    FLIPKART = "flipkart"
    RAKUTEN = "rakuten"
    JD_COM = "jd_com"
    LAZADA = "lazada"
    SHOPEE = "shopee"
    COUPANG = "coupang"
    # Gaming platforms
    PLAYSTATION = "playstation"
    XBOX = "xbox"
    NINTENDO = "nintendo"
    STEAM = "steam"
    EPIC_GAMES = "epic_games"
    BATTLE_NET = "battle_net"
    RIOT_GAMES = "riot_games"
    UBISOFT = "ubisoft"
    EA_ORIGIN = "ea_origin"
    STRAVA = "strava"
    FITBIT = "fitbit"
    GARMIN = "garmin"
    PELOTON = "peloton"
    BANDCAMP = "bandcamp"
    DEVIANTART = "deviantart"
    FIGMA = "figma"
    NOTION = "notion"
    LINEAR = "linear"
    DIGITALOCEAN = "digitalocean"
    HEROKU = "heroku"
    # Enterprise / Workforce federation
    OKTA = "okta"
    AUTH0 = "auth0"
    KEYCLOAK = "keycloak"
    MICROSOFT_ENTRA_ID = "microsoft_entra_id"
    GOOGLE_WORKSPACE = "google_workspace"
    ADFS = "adfs"
    ACTIVE_DIRECTORY = "active_directory"
    LDAP = "ldap"
    PING_FEDERATE = "ping_federate"
    # Generic protocols
    SAML = "saml"
    OPENID_CONNECT = "openid_connect"
    # Custom
    CUSTOM = "custom"
    # Provider categories
    SOCIAL = "social"
    ENTERPRISE = "enterprise"
    CHINESE = "chinese"
# ==============================================================================
# AUTHORIZATION MODELS
# ==============================================================================


class AuthorizationModel(str, Enum):
    """Authorization model types."""
    RBAC = "rbac"
    ABAC = "abac"
    REBAC = "rebac"
    POLICY_ENGINE = "policy_engine"
# ==============================================================================
# PASSWORD HASH ALGORITHMS
# ==============================================================================


class PasswordHashAlgorithm(str, Enum):
    """Password hashing algorithms."""
    BCRYPT = "bcrypt"
    ARGON2 = "argon2"
    SCRYPT = "scrypt"
    PBKDF2 = "pbkdf2"
# ==============================================================================
# TYPE ALIASES
# ==============================================================================
# User ID type
UserID = str
# Client ID type
ClientID = str
# Token string type
TokenString = str
# Scope string type
ScopeString = str
# Session ID type
SessionID = str
# Provider name type
ProviderName = str
# Configuration dictionary type
ConfigDict = dict[str, Any]
