#!/usr/bin/env python3
"""
OpenID Connect Core 1.0 access token hash checks (*at_hash*, *c_hash*).

Implements the SHA-256 / left-half / Base64URL encoding path used with RS256, ES256, PS256, HS256
and other JWS algorithms that use SHA-256 for the token signature (typical for enterprise IdPs).
"""

from __future__ import annotations

import base64
import hashlib
import secrets
from typing import Any


def _b64url_decode_segment(value: str) -> bytes:
    pad = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + pad).encode("ascii"))


def compute_at_hash(access_token: str, signing_alg: str | None = None) -> str:
    """
    Compute *at_hash* claim value for *access_token* (ASCII/UTF-8 octets of the token string).

    *signing_alg* is reserved for future JWA-specific digest selection; current path matches
    OIDC Core for algorithms backed by SHA-256 on the access token octets.
    """
    _ = signing_alg
    digest = hashlib.sha256(access_token.encode("utf-8")).digest()[:16]
    return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def verify_at_hash(access_token: str, at_hash_claim: Any, signing_alg: str | None) -> bool:
    """Return True if *at_hash_claim* matches the computed hash for *access_token*."""
    if not isinstance(at_hash_claim, str) or not at_hash_claim.strip():
        return False
    expected = compute_at_hash(access_token, signing_alg=signing_alg)
    try:
        a = _b64url_decode_segment(expected)
        b = _b64url_decode_segment(at_hash_claim.strip())
    except Exception:
        return False
    if len(a) != len(b):
        return False
    return secrets.compare_digest(a, b)


def compute_c_hash(authorization_code: str, signing_alg: str | None = None) -> str:
    """*c_hash* uses the same construction as *at_hash* over the authorization code string."""
    return compute_at_hash(authorization_code, signing_alg=signing_alg)


def verify_c_hash(authorization_code: str, c_hash_claim: Any, signing_alg: str | None) -> bool:
    """Return True if *c_hash_claim* matches the computed hash for *authorization_code*."""
    return verify_at_hash(authorization_code, c_hash_claim, signing_alg)
