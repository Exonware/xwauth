#!/usr/bin/env python3
"""
Federation broker exports.
"""

from .types import FederatedIdentity
from .broker import FederationBroker
from .errors import FederationUpstreamCode, XWFederationError, federation_exception_to_oauth_response
from .mapping import apply_claim_mapping_v1
from .idp_registry import (
    TenantScopedIdpRegistry,
    TenantIdpRecord,
    IdpHealthSnapshot,
    idp_isolation_namespace,
    idp_record_to_discovery_response,
)
from .pkce import generate_pkce_pair
from .jwks_cache import JwksDocumentCache
from .oidc_id_token import (
    OidcIdTokenValidationParams,
    decode_id_token_unverified,
    fetch_jwks,
    fetch_openid_configuration,
    validate_federated_id_token,
)

__all__ = [
    "FederatedIdentity",
    "FederationBroker",
    "FederationUpstreamCode",
    "XWFederationError",
    "federation_exception_to_oauth_response",
    "apply_claim_mapping_v1",
    "TenantScopedIdpRegistry",
    "TenantIdpRecord",
    "IdpHealthSnapshot",
    "idp_isolation_namespace",
    "idp_record_to_discovery_response",
    "generate_pkce_pair",
    "JwksDocumentCache",
    "OidcIdTokenValidationParams",
    "decode_id_token_unverified",
    "fetch_jwks",
    "fetch_openid_configuration",
    "validate_federated_id_token",
]

