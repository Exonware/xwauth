#!/usr/bin/env python3
"""
#exonware/xwauth/src/exonware/xwauth/__init__.py
XWOAuth (xwauth) - Centralized universal authorization system (REF_01_REQ, REF_15_API).
OAuth 1, OAuth 2, OIDC, SAML; 100+ connectors; library + APIs + UIs. Used by xwstorage,
xwbase, all Exonware APIs; replaces Firebase Auth and more. REF_22_PROJECT.
"""
# =============================================================================
# XWLAZY INTEGRATION — GUIDE_00_MASTER: config_package_lazy_install_enabled (EARLY)
# =============================================================================
# Dependency: exonware-xwlazy (optional; install exonware-xwauth[lazy] or [dev]).
try:
    from exonware.xwlazy import config_package_lazy_install_enabled

    config_package_lazy_install_enabled(
        __package__ or "exonware.xwauth",
        enabled=True,
        mode="smart",
    )
except ImportError:
    # xwlazy not installed — omit [lazy] extra or install exonware-xwlazy for lazy mode.
    pass
from .version import __version__, __author__, __email__
# Core exports
from .facade import XWAuth, create_webauthn_challenge_store, create_webauthn_credential_index_redis
from .authentication.attestation_trust import build_pem_root_certs_bytes_by_fmt
from .authentication.mfa_webauthn_audit import audit_mfa_event, audit_webauthn_event
from .authentication.webauthn import WebAuthnManager
from .authentication.webauthn_credential_index import (
    rebuild_webauthn_credential_index,
    register_webauthn_credential_mapping,
    resolve_user_for_webauthn_credential,
    unregister_webauthn_credential_mapping,
)
from .config.config import XWAuthConfig
from .contracts import AuthContext, IAuthContextResolver, IStorageProvider, IRateLimiter, IAuditLogger
from .base import ABaseAuth
from .errors import (
    XWAuthError,
    XWOAuthError,
    XWTokenError,
    XWProviderError,
    XWConfigError,
    XWValidationError,
    XWMFAError,
    XWMFAInvalidCodeError,
    XWMFARequiredError,
    XWWebAuthnError,
    XWWebAuthnChallengeError,
    XWWebAuthnCredentialError,
    XWCSRFError,
    XWRateLimitError,
)
from .defs import GrantType, TokenType, SessionStatus, UserStatus
# Extended from xwsystem (xwauth extends xwsystem)
from .providers.xwsystem_providers import OAuth2Provider, JWTProvider, SAMLProvider, EnterpriseAuth
# Client-side OAuth and session management
from .clients.oauth_client import OAuth2ClientManager
from .clients.entity_session_manager import EntitySessionManager
from .clients.oauth2_client import OAuth2Session
from .clients.async_client import AsyncOAuth2Session
# OAuth 1.0 support
from .core.oauth1 import OAuth1Server, OAuth1Client, OAuth1Signature, OAuth1RequestValidator
# JOSE library
from .jose import JWTManager, JWSManager, JWEManager, JWKManager, JWAManager, JOSEKeyManager
# Advanced RFC support
from .core.rfc import RFC9101BrowserBasedApps, RFC9207IssuerIdentification, RFC9068JWTProfile, RFC7521JWTBearerToken
from .extensions import IAuthHook, AuthHookRegistry
from .federation import FederationBroker, FederatedIdentity
__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__email__",
    # Main classes
    "XWAuth",
    "create_webauthn_challenge_store",
    "WebAuthnManager",
    "build_pem_root_certs_bytes_by_fmt",
    "audit_mfa_event",
    "audit_webauthn_event",
    "register_webauthn_credential_mapping",
    "unregister_webauthn_credential_mapping",
    "rebuild_webauthn_credential_index",
    "resolve_user_for_webauthn_credential",
    "XWAuthConfig",
    # Interfaces
    "IStorageProvider",
    "AuthContext",
    "IAuthContextResolver",
    "IRateLimiter",
    "IAuditLogger",
    # Base classes
    "ABaseAuth",
    # Errors
    "XWAuthError",
    "XWOAuthError",
    "XWTokenError",
    "XWProviderError",
    "XWConfigError",
    "XWValidationError",
    "XWMFAError",
    "XWMFAInvalidCodeError",
    "XWMFARequiredError",
    "XWWebAuthnError",
    "XWWebAuthnChallengeError",
    "XWWebAuthnCredentialError",
    "XWCSRFError",
    "XWRateLimitError",
    # Enums
    "GrantType",
    "TokenType",
    "SessionStatus",
    "UserStatus",
    # Extended from xwsystem (xwauth extends xwsystem)
    "OAuth2Provider",
    "JWTProvider",
    "SAMLProvider",
    "EnterpriseAuth",
    # Client-side OAuth and session management
    "OAuth2ClientManager",
    "EntitySessionManager",
    "OAuth2Session",
    "AsyncOAuth2Session",
    # OAuth 1.0 support
    "OAuth1Server",
    "OAuth1Client",
    "OAuth1Signature",
    "OAuth1RequestValidator",
    # JOSE library
    "JWTManager",
    "JWSManager",
    "JWEManager",
    "JWKManager",
    "JWAManager",
    "JOSEKeyManager",
    # Advanced RFC support
    "RFC9101BrowserBasedApps",
    "RFC9207IssuerIdentification",
    "RFC9068JWTProfile",
    "RFC7521JWTBearerToken",
    "IAuthHook",
    "AuthHookRegistry",
    "FederationBroker",
    "FederatedIdentity",
]
